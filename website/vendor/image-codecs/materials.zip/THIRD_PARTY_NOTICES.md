# Experimental image codec materials

This software is based in part on the work of the Independent JPEG Group.

heic-to and the libheif/libde265 decoder are LGPL-3.0-or-later as stated in their source notices. Complete GPLv3/LGPLv3 texts are included in upstream COPYING/LICENSE files. Other components retain their exact Apache, BSD, MIT, zlib, 0BSD and Unicode notices below.

The standalone HEIC module may be modified and replaced for your own use. Reverse engineering for debugging such modifications is permitted; no application term here restricts LGPL rights. Sources and rebuild/replacement instructions accompany these materials. No technical integrity check in the host rejects an interface-compatible replacement. This is an experimental local distribution bundle, not a published website or legal certification.

See manifest.json for original source refs, checksums and every collected notice. See application-source/image-codecs/DEPENDENCIES.md for findings and limitations.
